#!/bin/bash
sudo apt update && sudo apt install cronie rsyslog chrony -y
sudo systemctl mask logrotate.timer man-db.timer dpkg-db-backup.timer apt-daily.timer apt-daily-upgrade.timer fstrim.timer anacron.timer systemd-tmpfiles-clean.timer
sudo systemctl mask --now ModemManager switcheroo-control avahi-daemon avahi-daemon.socket colord.service accounts-daemon.service
sudo systemctl mask --now libvirtd.socket libvirtd-ro.socket libvirtd-admin.socket virtlockd.socket virtlockd-admin.socket virtlogd.socket virtlogd-admin.socket
sudo systemctl mask getty@tty3.service getty@tty4.service getty@tty5.service getty@tty6.service
sudo cp logind.conf /etc/systemd/logind.conf
sudo cp journald.conf /etc/systemd/journald.conf
sudo systemctl daemon-reload
sudo systemctl restart systemd-journald
sudo systemctl restart systemd-logind
