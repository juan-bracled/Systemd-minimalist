#!/bin/bash
echo "--- Iniciando systemd-minimalist (Fondo Negro + Sin Avahi) ---"

# 1. Herramientas y limpieza de imagen de arranque
sudo apt update
sudo apt install cronie rsyslog chrony -y
sudo apt purge plymouth plymouth-themes -y
sudo apt autoremove -y

# 2. Configuración de GRUB (asegurar quiet sin splash)
sudo sed -i 's/quiet splash/quiet/g' /etc/default/grub
sudo update-grub
sudo update-initramfs -u

# 3. Máscaras de servicios, timers y sockets (incluye Avahi error fix)
sudo systemctl mask logrotate.timer man-db.timer dpkg-db-backup.timer apt-daily.timer apt-daily-upgrade.timer fstrim.timer anacron.timer systemd-tmpfiles-clean.timer
sudo systemctl mask --now ModemManager switcheroo-control avahi-daemon avahi-daemon.socket colord.service accounts-daemon.service
sudo systemctl mask --now libvirtd.socket libvirtd-ro.socket libvirtd-admin.socket virtlockd.socket virtlockd-admin.socket virtlogd.socket virtlogd-admin.socket
sudo systemctl mask getty@tty3.service getty@tty4.service getty@tty5.service getty@tty6.service

# 4. Restaurar archivos de configuración
sudo cp logind.conf /etc/systemd/logind.conf
sudo cp journald.conf /etc/systemd/journald.conf

# 5. Reiniciar servicios para aplicar
sudo systemctl daemon-reload
sudo systemctl restart systemd-journald
sudo systemctl restart systemd-logind

echo "--- Instalación completada: Tu Debian es ahora minimalista y pura ---"
